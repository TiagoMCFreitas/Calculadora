/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tp.modelos;

/**
 *
 * @author tiago
 */
public class Calculadora {
private double ValorUm = 0.0;
private double ValorDois = 0.0;


    //Atributos
    public double getValorUm() {
        return ValorUm;
    }

    public void setValorUm(double ValorUm) {
        this.ValorUm = ValorUm;
    }

    public double getValorDois() {
        return ValorDois;
    }

    public void setValorDois(double ValorDois) {
        this.ValorDois = ValorDois;
    }
    //Metodos
     public double calcularSoma() {
     return (ValorUm + ValorDois);   
    }
     public double calcularMultiplicacao(){ 
     return (ValorUm * ValorDois);   
    }
     public double calcularSubtracao(){ 
     return (ValorUm - ValorDois);   
     }
     public double calcularDivisao()throws Exception{   
     if(ValorDois == 0) throw new Exception("Não existem divisões por zero");
     return (ValorUm/ValorDois);
     }
     public double calcularPotencia(){   
     return(Math.pow(ValorUm,ValorDois));
     }
     public double calcularRaiz()throws Exception{
     if(ValorUm == 0 || ValorDois <= 0)throw new Exception ("Não existem raízes de números negativos, ou índices negativos");
     return (Math.pow(ValorDois,1/ValorUm));
     }
     public int numeroumNegativo(){
        return(int)(-ValorUm);
    }
     public int numerodoisNegativo(){
       return(int)(-ValorDois);
   }
        
    
}
