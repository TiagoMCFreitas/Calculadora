/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tp.modelos;

/**
 *
 * @author tiago
 */
public class Conversor {
private float celcius = 0;
private float farenheit = 0;
private float kelvin = 0;
private float minuto = 0;
private float segundo = 0;
private float hora = 0;
private float metro = 0;
private float centimetro = 0;
private float milimetro = 0;

    public float getMetro() {
        return metro;
    }

    public void setMetro(float metro)throws Exception{
        if(metro == 0) throw new Exception("Insira um Valor");
        this.metro = metro;
    }

    public float getCentimetro() {
        return centimetro;
    }

    public void setCentimetro(float centimetro)throws Exception{
        if(centimetro == 0) throw new Exception("Insira um Valor");
        this.centimetro = centimetro;
    }

    public float getMilimetro() {
        return milimetro;
    }

    public void setMilimetro(float milimetro) throws Exception{
        if(milimetro == 0) throw new Exception("Insira um Valor");
        this.milimetro = milimetro;
    }

    public float getMinuto() {
        return minuto;
    }

    public void setMinuto(float minuto)throws Exception{
        if(minuto == 0) throw new Exception("Insira um Valor");
        this.minuto = minuto;
    }

    public float getSegundo() {
        return segundo;
    }

    public void setSegundo(float segundo) throws Exception{
        if(segundo == 0) throw new Exception("Insira um Valor");
        this.segundo = segundo;
    }

    public float getHora() {
        return hora;
    }

    public void setHora(float hora) throws Exception{
        if(hora == 0) throw new Exception("Insira um Valor");
        this.hora = hora;
    }
    
    public float getCelcius() {
        return celcius;
    }

    public void setCelcius(float celcius)throws Exception{
        if(celcius == 0) throw new Exception("Insira um Valor");
        this.celcius = celcius;
    }

    public float getFarenheit() {
        return farenheit;
    }

    public void setFarenheit(float farenheit)throws Exception{
        if(farenheit == 0) throw new Exception("Insira um Valor"); 
        this.farenheit = farenheit;
    }

    public float getKelvin() {
        return kelvin;
    }

    public void setKelvin(float kelvin) throws Exception{
        if(kelvin == 0) throw new Exception("Insira um Valor"); 
        this.kelvin = kelvin;
    }
    public float calcularcelciusFarenheit() {
    return (float)(celcius * 1.8 + 32);
    }
    public float calcularfarenheitCelcius(){
    return (float)((farenheit - 32)/1.8);
    } 
    public float calcularcelciusKelvin(){
       return (float)(celcius + 273.15); 
    }
    public float calcularkelvinCelcius(){
        return (float)(kelvin - 273.15);
    }
    public float calcularfarenheitKelvin(){
        return (float)((farenheit - 32)/1.8 + 273.15);
    }
    public float calcularkelvinFarenheit(){
        return(float)((kelvin -273.15) * 1.8 +32);
    }
    public float calcularminSeg(){
        return(float)(minuto * 60);
    }
    public float calcularsegMin(){
        return(float)(segundo/60);
    }
    public float calcularminHora(){
        return (float)(minuto/60);
    }
    public float calcularhoraMin(){
        return(float)(hora * 60);
        
    }
    public float calcularsegHora(){
        return(float)(segundo/3600);
    }
    public float calcularhoraSeg(){
        return(float)(hora * 3600);
    }
    public float calcularmilimetroMetro(){
     return(float)(milimetro/1000000);   
    }
    public float calcularmetroMilimetro(){
     return(float)(metro * 1000000);    
    }
    public float calcularmetroCentimetro(){
    return(float)(metro/10000);      
    }
    public float calcularcentimetroMetro(){
    return(float)(centimetro * 10000);      
    }
    public float calcularmilimetroCentimetro(){
    return(float)(milimetro/100);       
    }
    public float calcularcentimetroMilimetro(){
    return(float)(centimetro * 100);      
    }
    
}



   
    
